package com.asistenteia.movil

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Pantalla única de configuración, construida por código (sin XML de diseño). */
class MainActivity : Activity() {
    private lateinit var aj: Ajustes
    private lateinit var raiz: LinearLayout
    private lateinit var estadoPermisos: LinearLayout
    private var swActivo: Switch? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        aj = Nucleo.ajustes(this)
        title = "Asistente IA"
        val sv = ScrollView(this)
        raiz = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(32)) }
        sv.addView(raiz)
        setContentView(sv)
        construir()
        intent?.getStringExtra("probar")?.let { /* reservado */ }
    }

    override fun onResume() {
        super.onResume()
        pintarPermisos()
        swActivo?.isChecked = aj.activo
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun titulo(t: String) = TextView(this).apply {
        text = t; textSize = 18f; setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, dp(20), 0, dp(6))
        raiz.addView(this)
    }

    private fun nota(t: String) = TextView(this).apply { text = t; textSize = 13f; setTextColor(Color.GRAY); raiz.addView(this) }

    private fun campo(etiqueta: String, valor: String, secreto: Boolean = false, guardar: (String) -> Unit): EditText {
        nota(etiqueta)
        val e = EditText(this).apply {
            setText(valor); setSingleLine(true)
            inputType = if (secreto) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT
            setOnFocusChangeListener { _, f -> if (!f) guardar(text.toString()) }
        }
        raiz.addView(e)
        return e
    }

    private fun boton(t: String, f: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() }; raiz.addView(this) }

    private fun construir() {
        raiz.removeAllViews()
        titulo("Asistente IA")
        swActivo = Switch(this).apply {
            text = "Escuchar la frase de activación"; isChecked = aj.activo
            setOnCheckedChangeListener { v, on ->
                if (!v.isPressed) return@setOnCheckedChangeListener
                if (on) {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        v.isChecked = false; pedirMicro(); return@setOnCheckedChangeListener
                    }
                    guardarTodo(); AsistenteService.iniciar(this@MainActivity)
                } else AsistenteService.parar(this@MainActivity)
            }
            raiz.addView(this)
        }

        titulo("Permisos")
        nota("Pulsa cada uno que quieras usar. Lo que no concedas simplemente no funcionará.")
        estadoPermisos = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        raiz.addView(estadoPermisos)

        titulo("Cerebro")
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Claude (API, necesita clave)", "Ollama (en tu PC, sin clave)"))
        sp.setSelection(if (aj.proveedor == "ollama") 1 else 0)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { aj.proveedor = if (pos == 1) "ollama" else "claude" }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        raiz.addView(sp)
        campo("Clave de la API de Claude", aj.claveApi, true) { aj.claveApi = it }
        campo("Modelo de Claude", aj.modeloClaude) { aj.modeloClaude = it }
        campo("Dirección de Ollama (IP del PC en tu wifi)", aj.urlOllama) { aj.urlOllama = it }
        campo("Modelo de Ollama", aj.modeloOllama) { aj.modeloOllama = it }

        titulo("Voz")
        campo("Frase de activación", aj.frase) { if (it.isNotBlank()) aj.frase = it }
        Switch(this).apply {
            text = "Silenciar los pitidos del micrófono"; isChecked = aj.silenciarPitidos
            setOnCheckedChangeListener { _, on -> aj.silenciarPitidos = on }
            raiz.addView(this)
        }

        titulo("Sobre ti")
        campo("Tu nombre", aj.nombre) { aj.nombre = it }
        campo("Cómo quieres que te llame", aj.apodo) { aj.apodo = it }
        campo("Tus gustos (opcional)", aj.gustos) { aj.gustos = it }

        titulo("Responder mensajes por ti")
        nota("Por seguridad todo empieza en «No». «Borrador»: te llega una notificación y tú pulsas Enviar. «Automático»: contesta solo (máx. 3 por hora y conversación; nunca si habla de dinero, claves o urgencias).")
        for ((paq, nombre) in APPS_MENSAJERIA) {
            val fila = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fila.addView(TextView(this).apply { text = nombre }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            val s = Spinner(this)
            val opc = listOf("No", "Borrador", "Automático")
            s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, opc)
            s.setSelection(aj.modoDe(paq).ordinal)
            s.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { aj.ponerModo(paq, ModoRespuesta.values()[pos]) }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
            fila.addView(s)
            raiz.addView(fila)
        }
        Switch(this).apply {
            text = "Permitir también grupos"; isChecked = aj.permitirGrupos
            setOnCheckedChangeListener { _, on -> aj.permitirGrupos = on }
            raiz.addView(this)
        }
        Switch(this).apply {
            text = "Avisar de que responde una IA «(Respuesta automática)»"; isChecked = aj.avisarIA
            setOnCheckedChangeListener { _, on -> aj.avisarIA = on }
            raiz.addView(this)
        }
        campo("Estilo de tus respuestas", aj.estiloRespuesta) { aj.estiloRespuesta = it }

        titulo("Probar")
        boton("Ver la cara") {
            if (!Settings.canDrawOverlays(this)) { pedirOverlay(); return@boton }
            guardarTodo(); AsistenteService.iniciar(this, AsistenteService.ACCION_ROSTRO)
        }
        val prueba = campo("Escribe una orden (sin hablar)", "") {}
        boton("Enviar orden") {
            val t = prueba.text.toString().trim()
            if (t.isEmpty()) return@boton
            guardarTodo()
            AsistenteService.iniciar(this, AsistenteService.ACCION_ORDEN, t)
            Toast.makeText(this, "Enviado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun guardarTodo() { currentFocus?.clearFocus() }

    // ---- permisos

    private fun fila(texto: String, ok: Boolean, accion: () -> Unit) {
        val bt = Button(this).apply {
            isAllCaps = false
            text = (if (ok) "✅ " else "⬜ ") + texto
            gravity = android.view.Gravity.START or android.view.Gravity.CENTER_VERTICAL
            setOnClickListener { accion() }
        }
        estadoPermisos.addView(bt)
    }

    private fun pintarPermisos() {
        if (!::estadoPermisos.isInitialized) return
        estadoPermisos.removeAllViews()
        fun tiene(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
        fila("Micrófono", tiene(Manifest.permission.RECORD_AUDIO)) { pedirMicro() }
        fila("Mostrar la cara sobre otras apps", Settings.canDrawOverlays(this)) { pedirOverlay() }
        if (Build.VERSION.SDK_INT >= 33) fila("Notificaciones", tiene(Manifest.permission.POST_NOTIFICATIONS)) { requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2) }
        fila("Cambiar el brillo", Settings.System.canWrite(this)) { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }
        val escuchaNotif = Settings.Secure.getString(contentResolver, "enabled_notification_listeners").orEmpty().contains(packageName)
        fila("Leer y contestar mensajes (acceso a notificaciones)", escuchaNotif) { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        val acc = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty().contains(packageName)
        fila("Acciones del sistema: inicio, atrás, bloquear… (accesibilidad)", acc) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        fila("Contactos y SMS (llamar y enviar SMS por nombre)", tiene(Manifest.permission.READ_CONTACTS) && tiene(Manifest.permission.SEND_SMS)) {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS), 3)
        }
        val ahorro = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        fila("Sin ahorro de batería (para que siga escuchando)", ahorro) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
    }

    private fun pedirMicro() = requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
    private fun pedirOverlay() = startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        pintarPermisos()
    }
}
