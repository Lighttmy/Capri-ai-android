# Asistente IA para Android

Versión móvil del asistente. En vez de mascota: al decir la frase de activación («oye asistente» por defecto) aparece una **ventana flotante solo con su cara**, con efecto glitch y la boca animada mientras habla.

## ⚠️ Estado honesto
No he podido compilar el APK ni probarlo en un móvil (aquí no hay acceso a los servidores de Google/Gradle). Lo que sí está comprobado:
- Todo el Kotlin **compila** contra el SDK de Android 33 (kotlinc, 0 errores).
- La lógica pura (detección de la frase, política de respuestas, límites, normalización de herramientas) pasa sus pruebas.
- La página de la cara (glitch + boca) se ha probado en Chromium.
Lo que depende del móvil real (reconocimiento de voz continuo, WebView flotante, notificaciones, permisos según fabricante) **puede necesitar ajustes**. Si algo falla, dime el síntoma.

## Compilar el APK
**Opción A – Android Studio:** abre esta carpeta, espera a que sincronice y pulsa *Build → Build APK(s)*.
**Opción B – GitHub:** sube la carpeta a un repositorio tuyo; la pestaña *Actions → Compilar APK → Run workflow* genera `app-debug.apk` descargable.
Instálalo en el móvil (permite «instalar apps desconocidas»).

## Primera configuración (pantalla principal de la app)
1. Pulsa cada permiso de la lista: micrófono, mostrar sobre otras apps, notificaciones, cambiar brillo, acceso a notificaciones (mensajes), accesibilidad (inicio/atrás/bloquear/captura), contactos+SMS y «sin ahorro de batería».
2. Elige cerebro: **Claude** (pega tu clave de API) u **Ollama** (IP de tu PC en la misma wifi, p. ej. `http://192.168.1.50:11434`; en el PC arranca Ollama con `OLLAMA_HOST=0.0.0.0`).
3. Activa «Escuchar la frase de activación».

## Qué puede hacer por voz
Volumen y brillo, linterna, abrir apps, llamar (abre el marcador), enviar SMS, alarmas y temporizadores, control de música, abrir webs/buscar, abrir ajustes (wifi, bluetooth, etc.), inicio/atrás/recientes/notificaciones/bloquear/captura, leer tus mensajes recientes y contestar a uno concreto («contesta a Ana que llego tarde»).

## Responder mensajes por ti — seguridad
- Por defecto **no contesta nada**. Por app: *No / Borrador / Automático*.
- *Borrador*: te llega una notificación con la respuesta y botones Enviar/Descartar.
- *Automático*: máx. 3 respuestas por hora y conversación; nunca contesta mensajes con dinero, claves, urgencias o datos sensibles (se queda en borrador); ignora códigos de verificación; grupos desactivados salvo que los actives.
- Por defecto añade «(Respuesta automática)» para que la otra persona sepa que es una IA (se puede quitar).
- Funciona usando el botón «Responder» de la notificación, así que solo vale para conversaciones con notificación activa.

## Límites
- Solo Android 8+. Wifi/Bluetooth: Android solo permite abrir su panel, no conmutarlos.
- La cara no aparece sobre la pantalla de bloqueo.
- Silenciar los pitidos del micrófono baja los volúmenes de notificación/sistema mientras escucha (se puede desactivar).
- En Android 14 el servicio de micrófono no puede arrancar solo al encender el móvil: abre la app una vez tras reiniciar.
- Escuchar siempre gasta batería.
