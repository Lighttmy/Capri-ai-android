import com.asistenteia.movil.*

var fallos = 0
fun check(cond: Boolean, msg: String) { if (!cond) { fallos++; println("FALLO: $msg") } }
fun <T> eq(got: T, want: T, msg: String) { if (got != want) { fallos++; println("FALLO: $msg → «$got», quería «$want»") } }

fun main() {
    // ---- palabra de activación
    fun b(t: String, f: String = "oye asistente") = Activacion.buscar(t, f)
    eq(b("oye asistente abre la calculadora"), "abre la calculadora", "frase completa")
    eq(b("Oye, asistente."), "", "solo la frase")
    eq(b("hoy asistente abre chrome"), "abre chrome", "oye mal oído")
    eq(b("ey asistente pon música"), "pon música", "ey")
    eq(b("hey asistente abre spotify"), "abre spotify", "hey")
    eq(b("asistente abre el bloc de notas"), "abre el bloc de notas", "sin oye")
    eq(b("oye a sistente abre word"), "abre word", "palabra partida")
    eq(b("oyeasistente abre word"), "abre word", "pegadas")
    eq(b("oye asistent abre word"), "abre word", "letra comida")
    eq(b("bueno oye asistente cierra eso"), "cierra eso", "con palabras antes")
    eq(b("oiga asistente hola"), "hola", "oiga")
    eq(b("ojo asistente sube el volumen"), "sube el volumen", "ojo")
    eq(b("jarvis enciende", "jarvis"), "enciende", "una palabra")
    eq(b("yarvis enciende", "jarvis"), "enciende", "una palabra con error")
    eq(b("abre la calculadora"), null, "sin activación")
    eq(b("me ha dicho que hoy hay que asistir a la reunión de ventas"), null, "no activar con frases parecidas")
    eq(b("el asistente de la tienda me dijo que no"), null, "mencionarlo no es llamarlo")
    eq(b(""), null, "vacío")

    // ---- política de mensajes
    fun m(t: String, rem: String = "Ana", grupo: Boolean = false) = Entrante("whatsapp", rem, t, grupo, "c1")
    eq(Politica.decidir(ModoRespuesta.AUTO, m("¿Vienes a cenar?"), false), Decision.AUTO, "auto normal")
    eq(Politica.decidir(ModoRespuesta.BORRADOR, m("¿Vienes a cenar?"), false), Decision.BORRADOR, "borrador")
    eq(Politica.decidir(ModoRespuesta.NO, m("hola"), false), Decision.IGNORAR, "desactivado")
    eq(Politica.decidir(ModoRespuesta.AUTO, m("hola", grupo = true), false), Decision.IGNORAR, "grupos desactivados")
    eq(Politica.decidir(ModoRespuesta.AUTO, m("hola", grupo = true), true), Decision.AUTO, "grupos permitidos")
    eq(Politica.decidir(ModoRespuesta.AUTO, m("Hazme un bizum de 20 euros"), false), Decision.BORRADOR, "dinero → nunca automático")
    eq(Politica.decidir(ModoRespuesta.AUTO, m("Pásame tu contraseña del wifi"), false), Decision.BORRADOR, "contraseña")
    eq(Politica.decidir(ModoRespuesta.AUTO, m("Es urgente, llámame"), false), Decision.BORRADOR, "urgente")
    eq(Politica.decidir(ModoRespuesta.AUTO, m("Tu código de verificación es 483920. No lo compartas"), false), Decision.IGNORAR, "código OTP")
    eq(Politica.decidir(ModoRespuesta.AUTO, m("hola", rem = "Tú"), false), Decision.IGNORAR, "mensaje propio")
    eq(Politica.decidir(ModoRespuesta.AUTO, m("hola", rem = "Jean"), false, miNombre = "jean"), Decision.IGNORAR, "mi nombre")
    eq(Politica.decidir(ModoRespuesta.AUTO, m("   "), false), Decision.IGNORAR, "vacío")
    check(Politica.esCodigo("Your code is 123456, do not share it"), "código en inglés")
    check(!Politica.esCodigo("Nos vemos a las 2030"), "un número suelto no es un código")
    eq(Politica.limpiarRespuesta("**Respuesta:** «Claro, voy para allá»"), "Claro, voy para allá", "limpiar")
    eq(Politica.limpiarRespuesta("Vale\n\nnos vemos"), "Vale nos vemos", "saltos de línea")
    eq(Politica.limpiarRespuesta("hola", prefijo = "🤖 "), "🤖 hola", "prefijo")
    eq(Politica.limpiarRespuesta("   "), "", "vacío tras limpiar")
    check(Politica.limpiarRespuesta("a".repeat(900)).length <= 401, "tope de longitud")

    // ---- límite de respuestas
    val l = LimitadorRespuestas(maxPorVentana = 2, ventanaMs = 1000)
    check(l.permite("c", "m1", 0), "primera")
    l.registrar("c", "m1", 0)
    check(!l.permite("c", "m1", 10), "el mismo mensaje no se contesta dos veces")
    check(l.permite("c", "m2", 20), "segunda")
    l.registrar("c", "m2", 20)
    check(!l.permite("c", "m3", 30), "tope por conversación")
    check(l.permite("otra", "m4", 30), "otra conversación")
    check(l.permite("c", "m5", 1500), "pasada la ventana vuelve a permitir")

    // ---- canon de herramientas
    fun c(n: String, a: Map<String, Any?>?) = Canon.llamada(n, a)
    eq(c("abrir_app", mapOf("app" to "Spotify")), "abrir_aplicacion" to mapOf<String, Any?>("nombre" to "Spotify"), "abrir_app")
    eq(c("Abrir Aplicación", mapOf("name" to "Chrome")).first, "abrir_aplicacion", "nombre con tilde y mayúsculas")
    eq(c("subir_volumen", mapOf()), "volumen" to mapOf<String, Any?>("accion" to "subir"), "subir_volumen")
    eq(c("volumen", mapOf("action" to "Fijar", "level" to "40%")), "volumen" to mapOf<String, Any?>("accion" to "fijar", "nivel" to 40), "volumen fijar")
    eq(c("brillo", mapOf("accion" to "fijar", "nivel" to 70.0)).second["nivel"], 70, "número decimal a entero")
    eq(c("bloquear_pantalla", null), "accion_sistema" to mapOf<String, Any?>("accion" to "bloquear"), "bloquear pantalla")
    eq(c("contestar", mapOf("message" to "vale", "nombre" to "Ana")), "responder_mensaje" to mapOf<String, Any?>("texto" to "vale", "contacto" to "Ana"), "responder")
    eq(c("alarma", mapOf("hour" to "7", "minutes" to 30)).second, mapOf<String, Any?>("hora" to 7, "minutos" to 30), "alarma")
    eq(c("temporizador", mapOf("seconds" to "90")).second["segundos"], 90, "temporizador")
    eq(c("llamar", mapOf("numero" to 612345678)).second["destino"], "612345678", "número a texto")
    eq(c("herramienta_inventada", mapOf("x" to 1)), "herramienta_inventada" to mapOf<String, Any?>("x" to 1), "desconocida")
    eq(c("abrir_aplicacion", mapOf("nombre" to "Paint", "app" to "Word")).second["nombre"], "Paint", "gana el argumento correcto")
    check(Esquema.herramientas.map { it.nombre }.toSet().size == Esquema.herramientas.size, "nombres de herramienta repetidos")

    if (fallos == 0) println("LÓGICA OK") else { println("$fallos fallos"); System.exit(1) }
}
